package com.fet.idtt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceBcmBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceBcmBackendApplication.class, args);
	}

}
