package com.fet.idtt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceBcmBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
